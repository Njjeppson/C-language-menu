#include <iostream>
using std::cout;
using std::cin;
using std::endl;
using std::string;
int main()
{
    int id = 0;
    string name = "";
    float balance = 0;
    cout << "Enter the name : " << endl;
    cin >> name;
    cout << "Enter the balance : " << endl;
    cin >> balance;
    int choice = 10;
    while (choice != 0) {
        cout << "Account Menu:" << endl;
        cout << "0. Quit Program" << endl;
        cout << "1. Display Account Information" << endl;
        cout << "2. Add a deposit to an account" << endl;
        cout << "3. Withdraw from an account" << endl;
        cout << "Your choice: " << endl;

        cin >> choice;
        if (choice == 1) {
            cout << "Account ID : " << id << "  Name: " << name << "  Balance: $" << balance << endl;

        }

        if (choice == 2) {
            float deposit = 0;
            cout << "Amount to deposit: " << endl;
            cin >> deposit;
            balance += deposit;
        }

        if (choice == 3) {
            float withdrawal = 0;
            cout << "Amount to withdraw: " << endl;
            cin >> withdrawal;
            balance -= withdrawal;
        }
    }
}
// std::cout << "Hello World!\n";